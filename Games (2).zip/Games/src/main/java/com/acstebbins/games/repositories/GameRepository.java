package com.acstebbins.games.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.acstebbins.games.models.Game;

@Repository
public interface GameRepository extends CrudRepository<Game, Long> {}
